function showMessage() {
    alert("CANNOT BORROW ANY ITEM!");
}
function showMessage() {
    alert("CANNOT BORROW ANY ITEM!");
}